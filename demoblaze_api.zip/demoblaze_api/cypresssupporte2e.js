// cypress/support/e2e.js
// archivo de soporte para configuraciones globales
import './commands'
