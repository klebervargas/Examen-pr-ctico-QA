// cypress/e2e/api_spec.cy.js
describe('Demoblaze API - Signup y Login', () => {
  const baseUrl = Cypress.config('baseUrl') || 'https://api.demoblaze.com'
  const username = 'klebervargas'
  const password = 'kv1985'

  it('Signup - intenta registrar el usuario (POST /signup)', () => {
    cy.request({
      method: 'POST',
      url: `${baseUrl}/signup`,
      body: {
        username,
        password
      },
      // No fallar test si el servidor devuelve 4xx/5xx — queremos validar la respuesta
      failOnStatusCode: false
    }).then((resp) => {
      // Validaciones razonables y flexibles:
      expect(resp.status).to.eq(200) // el endpoint normalmente responde 200 incluso con mensajes
      // Convertir body a string para comparar mensajes
      const bodyStr = (typeof resp.body === 'object') ? JSON.stringify(resp.body) : String(resp.body)

      // Aceptamos tanto signup correcto como "user already exists"
      expect(bodyStr.toLowerCase()).to.match(/(sign up successful|signup successful|sign up|success|user already exists|already exists|ok)/i)
    })
  })

  it('Login - intenta iniciar sesión (POST /login)', () => {
    cy.request({
      method: 'POST',
      url: `${baseUrl}/login`,
      body: {
        username,
        password
      },
      failOnStatusCode: false
    }).then((resp) => {
      // Validar código y contenido
      expect(resp.status).to.eq(200)

      const bodyStr = (typeof resp.body === 'object') ? JSON.stringify(resp.body) : String(resp.body)

      // Aceptamos respuestas de login exitoso o mensajes de error legibles
      expect(bodyStr.toLowerCase()).to.match(/(login successful|logged in|success|ok|incorrect|wrong)/i)
    })
  })
})
