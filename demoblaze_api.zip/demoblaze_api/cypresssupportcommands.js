// cypress/support/commands.js
// Aquí puedes añadir comandos personalizados si los necesitas (por ahora vacío)
