DEMOBLAZE API - PRUEBAS (Cypress)
================================

Requisitos:
- Node.js (>=14)
- npm o yarn
- (Opcional) Postman si quieres importar la colección JSON

Archivos incluidos:
- package.json
- cypress.config.js
- cypress/e2e/api_spec.cy.js
- postman_collection.json (opcional)
- README.txt
- CONCLUSIONES.txt

Instalación y ejecución:
1) Clonar o copiar la carpeta "demoblaze-api-tests" en tu máquina.
2) Entrar en la carpeta:
   cd demoblaze-api-tests

3) Instalar dependencias:
   npm install

4) Ejecutar en modo abierto (UI) para depurar:
   npm run test:open
   - En la UI de Cypress selecciona el spec "api_spec.cy.js".

5) Ejecutar en modo headless (genera reporte mochawesome HTML en /reports):
   npm run test:run

6) Revisar reportes (si ejecutaste test:run):
   - El reporte HTML se encontrará en el directorio 'reports' (dependiendo de tu configuración).
   - Si no aparece el reporte, revisa salida de consola para ruta exacta.

Uso de Postman (opcional):
- Importa el archivo postman_collection.json en Postman.
- Ejecuta las dos peticiones (Signup, Login) con body JSON:
  {
    "username": "klebervargas",
    "password": "kv1985"
  }

Empaquetado:
- Empaqueta toda la carpeta "demoblaze-api-tests" en un zip.
- Incluye todos los archivos y la carpeta node_modules NO es necesaria (se puede regenerar con npm install).
- Envía el zip a las direcciones de correo indicadas por el proceso de selección.

Notas:
- Los tests son flexibles respecto al mensaje textual que devuelve la API (puede indicar "user already exists" si el usuario ya fue creado).
- Si quieres usar otro usuario, edita las variables username/password en cypress/e2e/api_spec.cy.js.
