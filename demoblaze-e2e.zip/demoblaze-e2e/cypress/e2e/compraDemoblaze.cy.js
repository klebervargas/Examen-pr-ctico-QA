describe('Flujo de compra en Demoblaze', () => {
  beforeEach(() => {
    cy.visit('https://www.demoblaze.com/')
  })

  it('Debe agregar dos productos al carrito, completar el formulario y finalizar la compra', () => {
    cy.contains('Samsung galaxy s6').click()
    cy.contains('Add to cart').click()
    cy.on('window:alert', (alertText) => {
      expect(alertText).to.contains('Product added')
    })
    cy.get('.navbar-brand').click()

    cy.contains('Nokia lumia 1520').click()
    cy.contains('Add to cart').click()
    cy.on('window:alert', (alertText) => {
      expect(alertText).to.contains('Product added')
    })
    cy.get('#cartur').click()

    cy.get('.success').should('have.length', 2)
    cy.contains('Place Order').click()

    cy.fixture('datosCompra').then((datos) => {
      cy.get('#name').type(datos.nombre)
      cy.get('#country').type(datos.pais)
      cy.get('#city').type(datos.ciudad)
      cy.get('#card').type(datos.tarjeta)
      cy.get('#month').type(datos.mes)
      cy.get('#year').type(datos.anio)
    })

    cy.contains('Purchase').click()
    cy.get('.sweet-alert').should('be.visible')
    cy.get('.confirm').click()
  })
})