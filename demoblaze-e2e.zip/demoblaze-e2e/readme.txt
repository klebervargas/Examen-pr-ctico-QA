EJERCICIO DE AUTOMATIZACIÓN E2E - DEMOBLAZE
-------------------------------------------

REQUISITOS:
1. Tener instalado Node.js (versión 18 o superior)
2. Descomprimir el archivo demoblaze-e2e.zip
3. Abrir una terminal (CMD o PowerShell) dentro de la carpeta del proyecto

INSTALACIÓN:
1. Ejecutar: npm install
2. Ejecutar: npx cypress open
   - Se abrirá la interfaz de Cypress
   - Seleccionar el archivo: cypress/e2e/compraDemoblaze.cy.js
   - Click en "Run" para ejecutar el test

REPORTE:
- Los resultados pueden verse en la interfaz de Cypress
